document.addEventListener("DOMContentLoaded", function() {
    alert("TON Education Mini App Loaded!");
});